package com.DuSchedule.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DuScheduleApplicationTests {

	@Test
	void contextLoads() {
	}

}
